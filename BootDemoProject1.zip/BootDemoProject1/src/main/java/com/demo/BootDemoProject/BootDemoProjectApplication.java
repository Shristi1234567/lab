package com.demo.BootDemoProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootDemoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootDemoProjectApplication.class, args);
	}

}
