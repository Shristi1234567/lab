package com.demo.BootDemoProject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Logincontroller 
{
 /*@RequestMapping("/home")
 public String getHomepage()
 {
	 return "home";
 }*/
 
	 @RequestMapping("/login")
	 public ModelAndView loginpage()
	 {
		 ModelAndView obj=new ModelAndView();
		 obj.setViewName("login");
		 obj.addObject("logus",new Loginstrater());
		 return obj;
	 }
	 @RequestMapping(value="/loginpg",method=RequestMethod.POST)
	 public ModelAndView loginpages(@ModelAttribute("logus") Loginstrater star)
	 {
		 ModelAndView obj=new ModelAndView();
		 System.out.println(star.getUsername()+","+star.getPassword());
		 obj.addObject("logus",star);
		 if(star.getUsername().equals("shristi") && star.getPassword().equals("shristi12"))
		 {
			 obj.setViewName("success");
		 }
		 else
		 {
			 obj.setViewName("failure");
		 }
		
		 return obj;
	 }
}
