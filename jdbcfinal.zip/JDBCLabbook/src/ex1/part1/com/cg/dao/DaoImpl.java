package ex1.part1.com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ex1.part1.com.cg.bean.Bean;
import ex1.part1.com.cg.dao.GetConnection;

public class DaoImpl {
	
	GetConnection gc = new GetConnection();
	Connection conn = null;
	PreparedStatement ps = null;
	int rows = 0;
	ResultSet rs = null; 

	public int insertData(Bean beanObj) {
		try {
			conn = gc.getConn();
			String sql = "insert into mapValues values(?,?)";
			ps = conn.prepareStatement(sql);
			ps.setInt(1,beanObj.getKey());
			ps.setString(2, beanObj.getValue());
			rows = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					
				}
				
			}
		}
			return rows;
		}

	public int deleteData(Integer key) {
		try {
			conn = gc.getConn();
			String sql = "delete from mapValues where keyId=?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1,key);
			rows = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					ps.close();
					conn.close();
				} catch (SQLException e) {
					
				}
				
			}
		}
			return rows;
		}
	
	@SuppressWarnings("rawtypes")
	public List<Bean> viewData() {
		@SuppressWarnings("unchecked")
		List<Bean> list = new ArrayList();
		try {
			conn = gc.getConn();
			String sql = "select * from mapValues order by value";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				Bean beanObj = new Bean();
				beanObj.setKey(rs.getInt("keyId"));
				beanObj.setValue(rs.getString("value"));
				list.add(beanObj);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(conn!=null) {
				try {
					rs.close();
					ps.close();
					conn.close();
				} catch (SQLException e) {
					
				}
				
			}
		}
			return list;
		}
	
	}
	


