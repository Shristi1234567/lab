package ex1.part1.com.cg.service;

import java.util.List;

import ex1.part1.com.cg.bean.Bean;
import ex1.part1.com.cg.dao.DaoImpl;

public class ServiceImpl {
	
	DaoImpl daoObj = new DaoImpl();
	int rows;

	public int insertData(Bean beanObj) {
		return daoObj.insertData(beanObj);
		
	}

	public int deleteData(Integer key) {
		return daoObj.deleteData(key);
		
	}

	public List<Bean> viewData() {
		List<Bean> list = daoObj.viewData();
		return list;
	}
}
