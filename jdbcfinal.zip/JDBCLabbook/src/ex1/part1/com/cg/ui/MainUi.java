package ex1.part1.com.cg.ui;

import java.util.List;
import java.util.Scanner;

import ex1.part1.com.cg.bean.Bean;
import ex1.part1.com.cg.service.ServiceImpl;

public class MainUi {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Bean beanObj = new Bean();
		ServiceImpl serviceObj = new ServiceImpl();
		char ch = 'y';
		Integer key;
		String value;
		int rows;
	
		while(ch!='n') {
			System.out.println("Enter 1 to insert data");
			System.out.println("Enter 2 to delete data");
			System.out.println("Enter 3 to view data");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter key");
				key = sc.nextInt();
				beanObj.setKey(key);
				System.out.println("Enter value");
				value = sc.next();
				beanObj.setValue(value);
				rows = serviceObj.insertData(beanObj);
				System.out.println(rows+" rows inserted");
				break;
			case 2:
				System.out.println("Enter key whose value you want to delete");
				key = sc.nextInt();
				rows = serviceObj.deleteData(key);
				System.out.println(rows+" rows deleted");
				break;
			case 3:
				List<Bean> list = serviceObj.viewData();
				System.out.println("Values in sorted order are: ");
				for(Bean itr : list)
					System.out.println(itr.getKey()+"-----"+itr.getValue());
				break;
			default:
				System.out.println("Invalid choice");
			}
			System.out.println("Do you want to continue? y or no");
			ch = sc.next().charAt(0);		
	}
}
}
