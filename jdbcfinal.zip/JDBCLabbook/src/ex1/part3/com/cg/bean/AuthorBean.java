package ex1.part3.com.cg.bean;

public class AuthorBean {

}
