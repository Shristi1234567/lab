import { Component, OnInit } from '@angular/core';
import {MathsService} from '../maths.service'
//import { getLocaleDateFormat } from '../../../node_modules/@angular/common';
@Component({
  selector: 'app-demo1',
  templateUrl: './demo1.component.html',
  styleUrls: ['./demo1.component.css']
})
export class Demo1Component implements OnInit {
  employees = [
    {
      id:'111',
      name:'Dolar'
    },
    {
      id:'222',
      name:'Capgemini'
    },
    {
      id:'333',
      name:'gold'
     }
  ]
showDiv=false
  constructor(private service:MathsService) { }

  ngOnInit() {

    // this.service.multiply();
  }
    getData()
    {
      alert(this.service.multiply(2,4))
    }
    addEmployee()
    {
      alert(this.service.addname(101,"Shristi",2000,"java"))
    }
    addEmployee11(id,name,salary,department)
    {
      this.service.display(id,name,salary,department)
      this.showDiv=true;
      // alert(id+name+salary+department)
    }

}
