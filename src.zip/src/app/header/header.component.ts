import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
showActions:boolean=true;
contacts=[
  {name:"xyz",email:"test1@xyz.com"},
  {name:"abc",email:"test1@abc.com"},
  {name:"xxx",email:"test1@xxx.com"},
  {name:"aaa",email:"test1@aaa.com"},
]
header:boolean=true;
}
