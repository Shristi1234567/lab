import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MathsService {

  add(a,b)
  {
    return a+b;
  }
  subtraction()
  {
    alert("subtraction")
  }

  multiply(a,b)
  {
    return a*b;
  }

  division()
  {
    alert("division")
  }
  addname(id,name,salary,depart)
  {
    return id+name+salary+depart;
  }
 display(id,name,salary,department)
 {
   alert("id is "+id+"name is "+name+"salary is "+salary+"department is "+department)
 }
  constructor() { }
}
